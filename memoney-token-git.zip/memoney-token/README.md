# MEMONEY (MEM) 🪙

Just a meme token on Solana.

## Overview
MEMONEY (MEM) is a meme token launched on the Solana blockchain via pump.fun.

There is no roadmap, no utility, and no promises of future value.
This repository exists for transparency and documentation only.

## Token Information
- **Name:** MEMONEY
- **Symbol:** MEM
- **Network:** Solana
- **Standard:** SPL Token
- **Decimals:** 9
- **Total Supply:** 1,000,000,000 MEM
- **Launch Platform:** pump.fun

## Mint Address
```
TBA (added after pump.fun deployment)
```

## Community
- **X Community:** https://x.com/i/communities/2012942969607790980/

## Authorities
- Mint Authority: pump.fun default
- Freeze Authority: pump.fun default

## Disclaimer
MEMONEY has no intrinsic value and no expectation of profit.
This is not an investment or a security.
The creator may sell tokens at any time.

Just a meme.
