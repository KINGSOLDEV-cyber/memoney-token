# MEMONEY FAQ

### What is MEMONEY?
A meme token launched on Solana using pump.fun.

### Does MEMONEY have utility?
No.

### Is MEMONEY an investment?
No. This is not a financial product.

### Where is the community?
X Community: https://x.com/i/communities/2012942969607790980/

### Can the creator sell tokens?
Yes.
