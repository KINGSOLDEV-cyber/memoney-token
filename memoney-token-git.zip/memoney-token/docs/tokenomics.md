# MEMONEY Tokenomics

## Supply
- Total Supply: 1,000,000,000 MEM
- Decimals: 9
- Supply is fixed at launch.

## Launch
- Token is launched publicly via pump.fun.
- Price discovery occurs through bonding curve mechanics.

## Notes
MEMONEY has no utility, roadmap, or guarantees.
High volatility is expected.
